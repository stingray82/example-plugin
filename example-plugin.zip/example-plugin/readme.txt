=== Example Plugin ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: Example 
Requires at least: 6.5
Tested up to: 6.8.1
Stable tag: 1.0.6.12
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This is just an example plugin to test updates

== Description ==

This is just an example plugin to test updates

== Installation ==

1. Upload the `example-plugin` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Update as needed

== Frequently Asked Questions ==

= How do I modify the settings =
There ae no settings on this plugin 
== Changelog == 
= 1.15 (March 2025) =
Fixed: Readme Issues  
Tweaked: Updater
= 1.14 =
Tweaked: Readme File  
New: Screenshot and Video Links  

= 1.13 =
New: Requires requirement for SureForms  

= 1.12 =
Fixed: Handle SureForms not being installed before installing HookSure gracefully  
New: `wp-safe_redirect` on deletion to prevent loop of deletion of newly added hook to the same ID that was just deleted  

= 1.11 =
Fixed: Plugin Description issue  

= 1.1 =
New: dynamic form fetching to replace manual form ID entry  
Improvement: admin interface for better usability  
Improvement: compatibility with WordPress 6.4  

= 1.0 =
New:  Initial release  